import { Login } from "./login";

export class registerstudent{
  stu_id:number=0;  
  name:string=" ";
  login:Login;
   password:string=" ";
    state:string="";
    city:string=" ";
    mobile_no:number = 0;
    dob: Date;
    qualification:string = " ";
    year_of_graduation: number=0;
  }