import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Exam_dtb } from '../Exam-dtb/Exam_dtb';
import { LoadquestionsService } from '../loadquestions.service';
import { ExamDtbService } from '../Services/exam-dtb.service';

@Component({
  selector: 'app-selectexam',
  templateUrl: './selectexam.component.html',
  styleUrls: ['./selectexam.component.css']
})
export class SelectexamComponent implements OnInit {
  examList: Exam_dtb[] = [];
  choice:number=0;
  constructor(private loadService:LoadquestionsService,private examService:ExamDtbService,private route:Router) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData() {
    this.examService.getEmpList().subscribe((data: Exam_dtb[]) => {
      this.examList = data;
    });
  }
  em:string=" ";
  next(){
    

    sessionStorage.setItem("exam_id",JSON.stringify(this.choice));
   
    for(let i=0;i<this.examList.length;i++){
      if(this.examList[i].exam_id==this.choice)
    {
    this.em=this.examList[i].exam_name;
    sessionStorage.setItem("exam_Name",this.em);
    }
    }
    this.route.navigate(['instructions']);
  }
 
  select:any;
    elist:exams[]=new Array<exams>()
    
    
      // constructor(private service:SelectexamService,private route:Router) { 
      //   this.load();
      // }
    // load(){
    //   this.service.get().subscribe(element=>{
    //     this.elist=element
    //     this.select=this.elist[0].exam_id
    //   })
}

    
  
    export class exams{
      examName:string="";
      exam_id:number=0;
      level:number=0;
    }
  