import { registerstudent } from "src/registerstudent";
import { Exam_dtb } from "../Exam-dtb/Exam_dtb";

export class ReportCard{



    exam_id:Exam_dtb;
    stu_id:registerstudent;
    marks:number=0;

    constuctor(exam_id:Exam_dtb,stu_id:registerstudent,marks:number){
            this.exam_id=exam_id;
        this.stu_id = stu_id;
        this.marks=marks;
        
    }
    } 
