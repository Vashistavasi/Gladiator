import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Question_Bank } from '../Exam-dtb/add-question/Question_Bank';
import { LoadquestionsService } from '../loadquestions.service';
import { SaveresponseService } from '../saveresponse.service';
import { ExamDtbService } from '../Services/exam-dtb.service';

@Component({
  selector: 'app-load-questions',
  templateUrl: './load-questions.component.html',
  styleUrls: ['./load-questions.component.css']
})
export class LoadQuestionsComponent implements OnInit {
  qlist:Array<question>=new Array<question>();
  qcurrent:question=new question();
  showquestion:boolean;
  qNo:number=0;
  resObject:ResponseDto=new ResponseDto();
  ei=sessionStorage.getItem("exam_id");
  ex=sessionStorage.getItem("exam_Name");
  email=sessionStorage.getItem("email_id");

session(){
  
  return sessionStorage.getItem("exam_id");

}


  query:string='';
  questionList: Question_Bank[] = [];
  b:boolean[]=[];
  questionListCurrent:Question_Bank=new Question_Bank();
show:boolean=true;

  constructor(private loadservice:LoadquestionsService,private saveService:SaveresponseService,private examService:ExamDtbService,private router: Router) {
  
   }
   ngOnInit(): void {
    // this.loadData();
    
    this.loadquestions();
    console.log("In ngonit");
    

  }
  submit(){
    for(let z=0;z<this.qlist.length;z++){
      console.log(this.qlist[z].response);
      this.qlist.forEach(element=>{
        
        this.resObject.response=this.qcurrent.response
      this.resObject.ques_Id=this.qcurrent.ques_Id
      this.resObject.exam_Id=this.qcurrent.exam_Id
        this.saveService.save(this.resObject).subscribe(element=>{element});
      })
      }
    this.router.navigate(['report']);
  }
  saveresponse(){
   
    this.resObject.response=this.qcurrent.response
    this.resObject.ques_Id=this.qcurrent.ques_Id
    this.resObject.exam_Id=this.qcurrent.exam_Id
  
    this.saveService.save(this.resObject).subscribe(element=>{element});
  }
 
 next1(){
this.saveresponse()
  if(this.qNo<this.qlist.length-1)
  {
  this.qNo++;
  }
  alert(JSON.stringify(this.qcurrent.response))
  this.showquestions1();
}
previous1(){
  this.saveresponse()
  if(this.qNo>0)
  {
  this.qNo--;
  }
  this.showquestions1();
}
showquestions1(){
  this.show=false;
  console.log(this.qlist.length);
  this.qcurrent=this.qlist[this.qNo]
    //alert(JSON.stringify(this.qcurrent))
    this.showquestion=true;
  }


  loadquestions(){
   
    this.loadservice.getquestion().subscribe(element=>{
      element.forEach(q=>{
        this.qlist.push(q)
       })
 })
 console.log("in Loadquestions1:" + this.qlist.length);
 }
  // loadData() {
  //   this.examService.getQuestionList().subscribe((data: Question_Bank[]) => {
  //     this.questionList = data;  
  //   });
// }
}
export class question{
  ques_Id:number=0;
  exam_Id:number=0;
question:string="";
options:Array<optionlist>;
response:string="";
}
export class optionlist{
  option:string
}
export class ResponseDto
{
 ques_Id:number=0;
 exam_Id:number=0;
response:string ="";
}
// next(){
//   this.saveresponse()
//   if(this.qNo<this.questionList.length-1)
//   {
//   this.qNo++
//   }
//   //alert(JSON.stringify(this.questionListCurrent.response))
//   this.showquestions()
// }
// previous(){
//   this.saveresponse()
//   if(this.qNo>0)
//   {
//   this.qNo--
//   }
//   this.showquestions()
// }
// showquestions(){
  
//   this.questionListCurrent=this.questionList[this.qNo];
//     alert(JSON.stringify(this.questionListCurrent))
//     this.showquestion=true;
//   }

//   submit(){
//       this.qlist.forEach(element=>{
//       this.resObject.response_id=element.responseid
//       this.resObject.response=element.response
      
//       this.saveService.save(this.resObject).subscribe(element=>{element});
//     })
//   }
 // console.log("just after loading data :" +this.questionList.length);
      // for( let i=0;i<this.questionList.length;i++){
      //   this.qlist[i].question=this.questionList[i].question;;
      //   this.qlist[i].options[0].option=this.questionList[i].option1;
      //   this.qlist[i].options[1].option=this.questionList[i].option2;
      //   this.qlist[i].options[2].option=this.questionList[i].option3;
      //   this.qlist[i].options[3].option=this.questionList[i].option4;
      //   console.log("the length "+this.qlist.length);
      // }
      // console.log("Loading data in questionList and the size is "+ this.questionList.length);
//  conversionIntoArray(){
//    console.log("inside conversion into array method");
//    console.log("the length of questionList is "+ this.questionList.length);
//    for( let i=0;i<question.length;i++){
   
//      this.qlist[i].question=this.questionList[i].question;
//      this.qlist[i].options[0].option=this.questionList[i].option1;
//      this.qlist[i].options[1].option=this.questionList[i].option2;
//      this.qlist[i].options[2].option=this.questionList[i].option3;
//      this.qlist[i].options[3].option=this.questionList[i].option4;
     
//    }
//  }

//     console.log(this.qlist.length);
//     for(let k=0;k<this.qlist.length;k++){
// console.log(this.qlist[k].question);
//     }
// responseconfig(){
//   console.log("The length of correct answers" );
// for(let z=0;z<this.qlist.length;z++){
//   this.correctResponses[z]=this.qlist[z].response;
// }

// }
  // console.log("Inside constructor");    
    // console.log(this.qlist.length);
    // for(let k=0;k<this.qlist.length;k++){
    //   console.log(this.qlist[k].question);
    //       }
    //       console.log("After for loop");