import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { registerstudent } from 'src/registerstudent';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-registerstudent',
  templateUrl: './registerstudent.component.html',
  styleUrls: ['./registerstudent.component.css']
})
export class RegisterstudentComponent implements OnInit {
  addForm: FormGroup;
  newStudentJson:any;
  submitted:boolean=false;
  register:registerstudent= new registerstudent();
;
  
  constructor(private registerService:RegisterService,private router: Router, private formBuilder: FormBuilder) { }
  ngOnInit(): void {
    this.addForm = this.formBuilder.group({
    stu_id:[], 
  name:[''],
  email_id:[''],
   password:[''],
    state:[''],
    city:[''],
    mobile_no:[],
    dob: new Date(),
    qualification:[''],
    year_of_graduation: [],
  });
}

onSubmit(){
  console.log("in submit");
    this.newStudentJson={
      // "stu_id":this.addForm.value.stu_id,
      "login":{
       "email_id":this.addForm.value.email_id,
       "password":this.addForm.value.password
      },
      "name" :this.addForm.value.name ,
      "password":this.addForm.value.password,
      "mobile_no": this.addForm.value.mobile_no,
      "city":this.addForm.value.city,
      "state":this.addForm.value.state,
      "dob":this.addForm.value.dob,
      "qualification":this.addForm.value.qualification,
      "year_of_graduation": this.addForm.value.year_of_graduation 

    };
    console.log(this.newStudentJson);
    console.log("record added  " + this.register);
    this.registerService.addNewStudent(this.newStudentJson).subscribe(data => console.log(data), error => console.log(error));
     this.register= new registerstudent();
     console.log("record added  " + this.register);
    this.submitted = true;
    this.router.navigate(['login']);
}
}
