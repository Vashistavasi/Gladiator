export class Login{
    
    email_id:string = "";
    accesstype:String="";
    password :string="";

}