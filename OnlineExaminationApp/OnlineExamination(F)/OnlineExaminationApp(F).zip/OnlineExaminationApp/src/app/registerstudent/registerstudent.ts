import { Login } from "src/login";

export class registerstudent{
    // stu_id:number=0;
login: Login | undefined ;
name: string = " ";
password:string = " ";
mobile_no:number = 0;
city:string = " ";
state:string = " ";
dob: Date | undefined;
qualification:string = " ";
year_of_graduation:number = 0; 

constuctor(stu_id:number,login:Login,name:string,password:string,mobile_no:number,city:string,state:string,dob:Date,qualification:string
    ,year_of_graduation:number){
        // this.stu_id=stu_id;
    this.login = login;
    this.name=name;
    this.password=password;
    this.mobile_no=mobile_no;
    this.city=city;
    this.state=state;
    this.dob=dob;
    this.qualification=qualification;
    this.year_of_graduation=year_of_graduation;
}
}