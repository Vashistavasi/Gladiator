import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-loginadmin',
  templateUrl: './loginadmin.component.html',
  styleUrls: ['./loginadmin.component.css']
})
export class LoginadminComponent implements OnInit {
  email_id:string="";
  password:string="";
 /* flagu:boolean=false;
  flagp:boolean=false;*/
  m:Msg=new Msg();
  constructor(private loginService:  LoginService,private router: Router) { }
    ngOnInit(): void {
    }
  
    loadData():void {
    

      this.loginService.checkDetailsAdmin(this.email_id,this.password).subscribe((data: any) => {
        this.m= data;
        console.log(this.m);
      
       /* return this.flagp;*/

      });
      if(this.m.msg[0]=="L"){
          
        this.router.navigate(['adminExam']);
      }
      
     /* this.loginService.adminCheck(this.email_id).subscribe((data: any) => {
        this.flagu= data;
        
      
      });
      if(this.flagu){
        this.msg="";
        this.loginService.checkDetails(this.email_id,this.password).subscribe((data: any) => {
          this.flagp= data;
        

        });

      }else if(!this.flagu){
        this.msg="User does not exist";
       
      }*/
     
      /*return false;*/
    }
    onSubmit() {
      /*setTimeout(()=>{ this.msg = "" }, 5000);*/
        this.loadData();
        
       /*
        else if(this.flagu && !this.flagp){
          this.msg="wrong password";
        }
  */
      }


}

export class Msg{
  msg:string="";

}

 
