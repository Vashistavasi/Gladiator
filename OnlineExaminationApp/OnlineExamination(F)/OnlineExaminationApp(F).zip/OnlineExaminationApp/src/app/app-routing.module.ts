import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminGetreportsComponent } from './admin-getreports/admin-getreports.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AddExamComponent } from './Exam-dtb/add-exam/add-exam.component';
import { AddQuestionComponent } from './Exam-dtb/add-question/add-question.component';
import { AdminExamComponent } from './Exam-dtb/admin-exam/admin-exam.component';
import { GetExamListComponent } from './Exam-dtb/get-exam-list/get-exam-list.component';
import { GetQuestionsComponent } from './Exam-dtb/get-questions/get-questions.component';
import { ExaminationInstructionComponent } from './examination-instruction/examination-instruction.component';
import { HomeLoginComponent } from './home-login/home-login.component';
import { HomeComponent } from './home/home.component';
import { LoadQuestionsComponent } from './load-questions/load-questions.component';
import { LoginComponent } from './login/login.component';
import { LoginadminComponent } from './loginadmin/loginadmin.component';
import { RegisterstudentComponent } from './registerstudent/registerstudent.component';
import { ReportCardComponent } from './report-card/report-card.component';
import { ReportCard } from './report-card/ReportCard';
import { SelectexamComponent } from './selectexam/selectexam.component';
import { ShowresultComponent } from './showresult/showresult.component';
import { StuportalComponent } from './stuportal/stuportal.component';
import { ViewReportComponent } from './view-report/view-report.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'addquestion', component: AddQuestionComponent },
  { path: 'viewquestions', component: GetQuestionsComponent },
  { path: 'stuportal', component: StuportalComponent },
  { path: 'selectexam', component: SelectexamComponent },
  { path: 'instructions', component: ExaminationInstructionComponent },
  { path: 'login', component: LoginComponent },
  { path: 'loginadmin', component: LoginadminComponent },
  { path: 'getStudentReports', component: AdminGetreportsComponent  },
  {path: 'viewreport', component:ViewReportComponent},
  { path: 'register', component: RegisterstudentComponent },
  { path: 'report', component: ReportCardComponent },
  { path: 'contactus', component:ContactusComponent},
  { path: 'adminExam', component: AdminExamComponent },
  { path: 'addnewExam', component: AddExamComponent },
  { path: 'ExamsList', component: GetExamListComponent },
  {path: 'homelogin', component:HomeLoginComponent },
  {path: 'about', component:AboutusComponent},
  {path: 'loadquestion', component:LoadQuestionsComponent},
  {path: 'showresult', component:ShowresultComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
