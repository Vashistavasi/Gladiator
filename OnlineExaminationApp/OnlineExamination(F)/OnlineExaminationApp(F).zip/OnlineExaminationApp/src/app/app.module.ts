import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AddExamComponent } from './Exam-dtb/add-exam/add-exam.component';
import { GetExamListComponent } from './Exam-dtb/get-exam-list/get-exam-list.component';
import { AdminExamComponent } from './Exam-dtb/admin-exam/admin-exam.component';
import { QuestionbankComponent } from './questionbank/questionbank.component';
import { ReportCardComponent } from './report-card/report-card.component';
import { HomeComponent } from './home/home.component';
import { ContactusComponent } from './contactus/contactus.component';
import { RegisterstudentComponent } from './registerstudent/registerstudent.component';
import { AddQuestionComponent } from './Exam-dtb/add-question/add-question.component';
import { GetQuestionsComponent } from './Exam-dtb/get-questions/get-questions.component';
import { SearchPipe } from './search.pipe';
import { StuportalComponent } from './stuportal/stuportal.component';
import { SelectexamComponent } from './selectexam/selectexam.component';
import { ExaminationInstructionComponent } from './examination-instruction/examination-instruction.component';
import { LoadQuestionsComponent } from './load-questions/load-questions.component';
import { HomeLoginComponent } from './home-login/home-login.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ShowresultComponent } from './showresult/showresult.component';
import { LoginadminComponent } from './loginadmin/loginadmin.component';
import { AdminGetreportsComponent } from './admin-getreports/admin-getreports.component';
import { ViewReportComponent } from './view-report/view-report.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AddExamComponent,
    GetExamListComponent,
    AdminExamComponent,
    QuestionbankComponent,
    ReportCardComponent,
    HomeComponent,
    ContactusComponent,
    RegisterstudentComponent,
    AddQuestionComponent,
    GetQuestionsComponent,
    SearchPipe,
    StuportalComponent,
    SelectexamComponent,
    ExaminationInstructionComponent,
    LoadQuestionsComponent,
    HomeLoginComponent,
    AboutusComponent,
    ShowresultComponent,
    LoginadminComponent,
    AdminGetreportsComponent,
    ViewReportComponent
    
    
  ],
  imports: [
    BrowserModule, FormsModule,
  
    AppRoutingModule, HttpClientModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
