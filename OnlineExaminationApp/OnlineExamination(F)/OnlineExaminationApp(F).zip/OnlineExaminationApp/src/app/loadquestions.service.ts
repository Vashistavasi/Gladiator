import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { question } from './load-questions/load-questions.component';
import { ExamDtbService } from './Services/exam-dtb.service';

@Injectable({
  providedIn: 'root'
})
export class LoadquestionsService {
  ans:string="";
  constructor(private examservice:ExamDtbService,private http:HttpClient) {} 
  baseUrl="http://localhost:8090//OnlineExam";


  getquestion():Observable<Array<question>>
  {
   
     return this.http.get<Array<question>>("http://localhost:8090//OnlineExam/beginexam/"+sessionStorage.getItem("exam_id"));
    // return this.examservice.getQuestionList();
  }

   
}
