import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stuportal',
  templateUrl: './stuportal.component.html',
  styleUrls: ['./stuportal.component.css']
})
export class StuportalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
