import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportCard } from '../report-card/ReportCard';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  private baseUrl="http://localhost:8090//OnlineExam";
  constructor(private http:HttpClient) { }
  getReport():any
  {
    console.log(this.http.get<ReportCard>(this.baseUrl+'/report'));
   return  this.http.get<ReportCard>(this.baseUrl+'/report');
  }
  getReportbyId():any
  {
    console.log(this.http.get<ReportCard>("http://localhost:8090//OnlineExam/reports/"+sessionStorage.getItem("email_id")));
   return  this.http.get<ReportCard>("http://localhost:8090//OnlineExam/reports/"+sessionStorage.getItem("email_id"));
  }
  allStudentReports():any
  {
    console.log(this.http.get<any[]>(this.baseUrl+'/all_student_reports'));
   return  this.http.get<any[]>(this.baseUrl+'/all_student_reports');
  }
}
