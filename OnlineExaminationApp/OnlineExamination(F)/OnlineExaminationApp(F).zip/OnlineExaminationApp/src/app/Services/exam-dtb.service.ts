import { HttpClient } from '@angular/common/http';
import { variable } from '@angular/compiler/src/output/output_ast';
import { Injectable } from '@angular/core';
import { ChildrenOutletContexts } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExamDtbService {



  private baseUrl="http://localhost:8090//OnlineExam";
  constructor(private http:HttpClient) { }

  getEmpList():any
{
  console.log(this.http.get<any[]>(this.baseUrl+'/ExamsList'));
 return  this.http.get<any[]>(this.baseUrl+'/ExamsList');
}

  addNewExam(addexam: Object): Observable<Object> {
    console.log(this.http.post(`${this.baseUrl}`+'/addnewExam', addexam))
    return this.http.post(`${this.baseUrl}`+'/addnewExam', addexam);
   }
  

   addNewQuestion(addQuestion: Object): Observable<Object> {
    console.log(this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion))
    return this.http.post(`${this.baseUrl}`+'/addquestion', addQuestion);
   }

   getQuestionList():any
   {
     console.log(this.http.get<any[]>(this.baseUrl+'/QuestionsList'));
    return  this.http.get<any[]>(this.baseUrl+'/QuestionsList');
   }
   
}
