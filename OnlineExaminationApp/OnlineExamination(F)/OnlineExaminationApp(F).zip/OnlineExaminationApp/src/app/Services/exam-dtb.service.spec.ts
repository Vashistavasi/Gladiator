import { TestBed } from '@angular/core/testing';

import { ExamDtbService } from './exam-dtb.service';

describe('ExamDtbService', () => {
  let service: ExamDtbService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExamDtbService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
