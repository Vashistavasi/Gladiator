import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { registerstudent } from 'src/registerstudent';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  
  private baseUrl="http://localhost:8090//OnlineExam";
  constructor(private http:HttpClient) { }

  addNewStudent(addStudent: Object): Observable<Object> {
    console.log(this.http.post(`${this.baseUrl}`+'/RegisterStudent', addStudent))
    return this.http.post(`${this.baseUrl}`+'/RegisterStudent', addStudent);
   }
}

