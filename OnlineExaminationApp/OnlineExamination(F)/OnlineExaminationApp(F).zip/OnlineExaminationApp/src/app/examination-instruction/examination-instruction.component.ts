import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-examination-instruction',
  templateUrl: './examination-instruction.component.html',
  styleUrls: ['./examination-instruction.component.css']
})
export class ExaminationInstructionComponent implements OnInit {

  navigate(){
    this.router.navigate(['loadquestion']);
  }
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

}
