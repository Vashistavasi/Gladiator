export class Exam_dtb{

  exam_id :number ;
  exam_name: string ;

passing_score_level1:number;

passing_score_level2 :number;

 passing_score_level3:number;

 duration_level1:number;

duration_level2:number;

 duration_level3:number;
}