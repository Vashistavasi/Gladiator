import { Component, OnInit } from '@angular/core';
import { ExamDtbService } from 'src/app/Services/exam-dtb.service';
import { Question_Bank } from '../add-question/Question_Bank';

@Component({
  selector: 'app-get-questions',
  templateUrl: './get-questions.component.html',
  styleUrls: ['./get-questions.component.css']
})
export class GetQuestionsComponent implements OnInit {
query:string='';
  questionList: Question_Bank[] = [];
  constructor(private examService:ExamDtbService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData() {
    this.examService.getQuestionList().subscribe((data: Question_Bank[]) => {
      this.questionList = data;
    });
}
}
