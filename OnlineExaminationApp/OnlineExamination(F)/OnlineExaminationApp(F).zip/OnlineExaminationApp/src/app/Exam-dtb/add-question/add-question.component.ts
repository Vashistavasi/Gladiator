import { Component, OnInit } from '@angular/core';
import { ExamDtbService } from 'src/app/Services/exam-dtb.service';
import { Question_Bank } from './Question_Bank';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.css']
})
export class AddQuestionComponent implements OnInit {

  addQuestion: Question_Bank = new Question_Bank ();
  submitted = false;
  constructor(private questionService: ExamDtbService) { }
  ngOnInit() {
  }
  
  newQuestion(): void {
    this.submitted = false;
    this.addQuestion = new Question_Bank ();
  }
 save() {
   
   this.questionService.addNewQuestion(this.addQuestion)
     .subscribe(data => console.log(data), error => console.log(error));
     this.addQuestion= new Question_Bank ();
     console.log("Question added" + this.addQuestion);
  }
  onSubmit() {
   this.submitted = true;
     this.save();
 }
}
