export class Question_Bank{
     ques_id:number;
        exam_id:number;
        question:string; 
        option1:string;
        option2: string;
        option3: string;
        option4: string;
        correct_answer:string;
        question_level: number;
        marks:number; 
        group_name:string;
}