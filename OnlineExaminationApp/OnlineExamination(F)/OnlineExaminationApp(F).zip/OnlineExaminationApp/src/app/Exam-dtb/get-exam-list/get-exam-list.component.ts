import { Component, OnInit } from '@angular/core';
import { ExamDtbService } from 'src/app/Services/exam-dtb.service';
import { Exam_dtb } from '../Exam_dtb';

@Component({
  selector: 'app-get-exam-list',
  templateUrl: './get-exam-list.component.html',
  styleUrls: ['./get-exam-list.component.css']
})
export class GetExamListComponent implements OnInit {

  

  examList: Exam_dtb[] = [];
  constructor(private examService:ExamDtbService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData() {
    this.examService.getEmpList().subscribe((data: Exam_dtb[]) => {
      this.examList = data;
    });
    
  }

}
