import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetExamListComponent } from './get-exam-list.component';

describe('GetExamListComponent', () => {
  let component: GetExamListComponent;
  let fixture: ComponentFixture<GetExamListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetExamListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetExamListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
