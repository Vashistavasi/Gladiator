import { Component, OnInit } from '@angular/core';
import { ExamDtbService } from 'src/app/Services/exam-dtb.service';
import { Exam_dtb } from '../Exam_dtb';

@Component({
  selector: 'app-add-exam',
  templateUrl: './add-exam.component.html',
  styleUrls: ['./add-exam.component.css']
})
export class AddExamComponent implements OnInit {

  addexam: Exam_dtb = new Exam_dtb();
  submitted = false;
  constructor(private examService: ExamDtbService) { }
  ngOnInit() {
  }
  
  newEmployee(): void {
    this.submitted = false;
    this.addexam = new Exam_dtb();
  }
 save() {
   
   this.examService.addNewExam(this.addexam)
     .subscribe(data => console.log(data), error => console.log(error));
     this.addexam= new Exam_dtb();
     console.log("exam  added" + this.addexam);
  }
  onSubmit() {
   this.submitted = true;
     this.save();
 }

}
