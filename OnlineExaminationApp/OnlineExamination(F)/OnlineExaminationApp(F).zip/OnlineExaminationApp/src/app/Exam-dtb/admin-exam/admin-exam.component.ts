import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-exam',
  templateUrl: './admin-exam.component.html',
  styleUrls: ['./admin-exam.component.css']
})
export class AdminExamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
