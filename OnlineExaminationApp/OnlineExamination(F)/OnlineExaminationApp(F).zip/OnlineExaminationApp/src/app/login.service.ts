import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Login } from 'src/login';
import { Msg } from './login/login.component';

@Injectable({
  providedIn: 'root'
})
export class LoginService {


  

    private baseUrl="http://localhost:8090/OnlineExam";
      constructor(private http:HttpClient) { }
    
      adminCheck(email_id:string):any
    {
      console.log(this.http.get<any>(this.baseUrl+'/AdminCheck/'+email_id));
     return  this.http.get<any>(this.baseUrl+'/AdminCheck/'+email_id);
    }
    checkDetailsAdmin(email_id:string,password:string):Observable<Msg>
    {
      console.log(this.http.get<Msg>(this.baseUrl+'/CheckDetailsAdmin/'+email_id+'/'+password));
     return  this.http.get<Msg>(this.baseUrl+'/CheckDetailsAdmin/'+email_id+'/'+password);
    }
    checkDetails(email_id:string,password:string):Observable<Msg>
    {
      console.log(this.http.get<Msg>(this.baseUrl+'/CheckDetails/'+email_id+'/'+password));
     return  this.http.get<Msg>(this.baseUrl+'/CheckDetails/'+email_id+'/'+password);
    }



    }


class ID{
  id:number | undefined;
}

