import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminGetreportsComponent } from './admin-getreports.component';

describe('AdminGetreportsComponent', () => {
  let component: AdminGetreportsComponent;
  let fixture: ComponentFixture<AdminGetreportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminGetreportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminGetreportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
