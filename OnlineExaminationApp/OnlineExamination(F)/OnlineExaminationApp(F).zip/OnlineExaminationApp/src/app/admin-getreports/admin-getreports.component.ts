import { Component, OnInit } from '@angular/core';

import { ReportCard } from '../report-card/ReportCard';
import { ReportService } from '../Services/report.service';

@Component({
  selector: 'app-admin-getreports',
  templateUrl: './admin-getreports.component.html',
  styleUrls: ['./admin-getreports.component.css']
})
export class AdminGetreportsComponent implements OnInit {
  reportList: ReportCard[] = [];
reportListDto:ReportCardDto[]=[];
  query:string='';
  constructor(private reportService:ReportService) { }

  ngOnInit(): void {
    this.loadData();
  
  }

  loadData() {
    this.reportService.allStudentReports().subscribe((data: ReportCard[]) => {
      this.reportList = data;
      console.log("Inside ngoninit Before dto for loop "+ this.reportList.length );
      for(let i=0;i<this.reportList.length;i++){
        console.log(i+" The iterating count" );
        this.reportListDto[i].exam_id=this.reportList[i].exam_id.exam_id;
        this.reportListDto[i].exam_name=this.reportList[i].exam_id.exam_name;
        this.reportListDto[i].stu_id=this.reportList[i].stu_id.stu_id;
        this.reportListDto[i].name=this.reportList[i].stu_id.name;
        this.reportListDto[i].marks=this.reportList[i].marks;
      }
    });
   
}
}
export class ReportCardDto{
  
     
        exam_id:number=0;
        exam_name:string="";
        passing_score_level1:number=0;
        passing_score_level2: number=0;
        passing_score_level3:number=0;
        duration_level1: number=0;
        duration_level2: number=0;
        duration_level3: number=0;

        stu_id: number=0;
        name: string;
        
            email_id: string="";
            password: string="";
            accesstype: string="";
     
        password1: string="";
        mobile_no: number=0;
        city:string="";
        state:string="";
        dob: Date=new Date();
        qualification:string;
        year_of_graduation: number=0;
    
    marks:number= 0;
}

