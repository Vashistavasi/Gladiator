import { Component, OnInit } from '@angular/core';
import { ReportCard } from '../report-card/ReportCard';
import { ReportService } from '../Services/report.service';

@Component({
  selector: 'app-view-report',
  templateUrl: './view-report.component.html',
  styleUrls: ['./view-report.component.css']
})
export class ViewReportComponent implements OnInit {

  report:ReportCard=new ReportCard();
  newReportJson:any;
    constructor(private reportCard:ReportService) { }
  
    ngOnInit(): void {
  this.loadData();
  
    }
     loadData() {
      this.reportCard.getReportbyId().subscribe((data: ReportCard) => {
        this.report = data;
      });
    }
    ei=sessionStorage.getItem('exam_id');
    ex=sessionStorage.getItem('exam_Name');
  onSubmit(){
    console.log("in submit");
      this.newReportJson={
        "exam_id": {
          "exam_id": this.report.exam_id.exam_id,
          "exam_name": this.report.exam_id.exam_name,
          "passing_score_level1": this.report.exam_id.passing_score_level1,
          "passing_score_level2": this.report.exam_id.passing_score_level2,
          "passing_score_level3": this.report.exam_id.passing_score_level3,
          "duration_level1": this.report.exam_id.duration_level1,
          "duration_level2": this.report.exam_id.duration_level2,
          "duration_level3": this.report.exam_id.duration_level3
      },
      "stu_id": {
          "stu_id": this.report.stu_id.stu_id,
          "name": this.report.stu_id.name,
          "login": {
              "email_id": this.report.stu_id.login.username,
              "password":this.report.stu_id.login.password
          },
          "password": this.report.stu_id.password,
          "mobile_no": this.report.stu_id.mobile_no,
          "city": this.report.stu_id.city,
          "state": this.report.stu_id.state,
          "dob": this.report.stu_id.dob,
          "qualification": this.report.stu_id.qualification,
          "year_of_graduation": this.report.stu_id.year_of_graduation
      },
      "marks": this.report.marks
  };
  
  
  
  }
}
