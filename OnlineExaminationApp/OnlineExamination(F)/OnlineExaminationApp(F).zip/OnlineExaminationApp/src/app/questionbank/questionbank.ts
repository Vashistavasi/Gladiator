export class questionbank{

    ques_id:number=0;
    exam_id: number = 0;
    question: String = "";
    option1: String ="";
    option2: String = "";
    option3:String=" ";
    option4:String=" ";
    correct_answer :String=" ";
    question_level: number = 0;
    marks: number = 0;
    group_name  :String=" ";
	active : number = 1;
    
}