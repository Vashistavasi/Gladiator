import { Component, OnInit } from '@angular/core';
import { questionbank } from './questionbank';

@Component({
  selector: 'app-questionbank',
  templateUrl: './questionbank.component.html',
  styleUrls: ['./questionbank.component.css']
})
export class QuestionbankComponent implements OnInit {

  Ques_bank :  questionbank[] = 
  [{ques_id : 1001,
   exam_id : 101,
    question:"What is Java",
  option1:"Animal",
  option2:"Sport",
  option3:"Language",
  option4:"person",
  correct_answer:"Language",
           question_level:1,
           marks:65,
           group_name:"Java",
           active:1}];



constructor() { }

ngOnInit(): void {
}
}
