package com.lti.services;

public interface QuestionBankService {

}
