package com.lti.services;

import com.lti.beans.Student_Details;


public interface StudentService {
	public String RegisterUser(Student_Details s);
}
