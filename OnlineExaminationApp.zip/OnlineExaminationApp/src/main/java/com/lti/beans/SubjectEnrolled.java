package com.lti.beans;

public class SubjectEnrolled {

}
