package com.lti.dto;
public class optionsDto {
private String option;

public optionsDto(String option) {
	super();
	this.option = option;
}
public optionsDto() {}

public String getOption() {
	return option;
}

public void setOption(String option) {
	this.option = option;
}
}

